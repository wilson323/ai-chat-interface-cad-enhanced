import FastGPTConnectionTest from "./fastgpt-connection"

export default function DiagnosticsPage() {
  return (
    <div className="container mx-auto py-8">
      <FastGPTConnectionTest />
    </div>
  )
}
