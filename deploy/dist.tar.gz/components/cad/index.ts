// 创建统一导出文件，解决组件引用问题
export { CADFileUploader } from './cad-file-uploader'
export { CADViewer } from './cad-viewer'
export { CADAnalysisResult } from './cad-analysis-result' 